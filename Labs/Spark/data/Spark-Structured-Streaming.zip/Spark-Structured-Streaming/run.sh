#!/bin/bash
source unset_jupyter.sh
spark-submit ./SparkStreamingFromDirectory.py
